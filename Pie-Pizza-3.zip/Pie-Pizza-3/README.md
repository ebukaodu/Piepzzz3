# Pie-Pizza-3
- Pie Pizza 3: move the Pizza Repository to a real database with full CRUD functionality to Add/Edit/Delete Pizza Menu Items (along with their images).
- Add Entity Framework and Database (with CRUD) to your pages
- Finding problems publishing. Patrick haven't fixed it yet
